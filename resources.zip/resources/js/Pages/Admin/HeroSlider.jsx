import React from "react";
import AdminLayout from "@/Layouts/AdminLayout";

/**
 * Hero Slider
 *
 * NOTE:
 * UI scaffold only. Wire to your hero slider module/controller later.
 */
export default function HeroSlider() {
  return (
    <AdminLayout active="hero" title="Hero Slider">
      <div className="rounded-2xl border border-white/10 bg-black/30 p-5">
        <div className="text-lg font-extrabold">Hero Slider</div>
        <div className="mt-2 text-sm text-white/70">
          Placeholder page. Existing module is handled elsewhere in your system.
        </div>
      </div>
    </AdminLayout>
  );
}
